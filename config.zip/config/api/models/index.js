// const Product = require('./products');
// const Order = require('./orders'); 
// const sequelize = require('../db'); 

// Order.belongsTo(Product, { foreignKey: 'productId' });
// Product.hasMany(Order, { foreignKey: 'productId', onDelete: 'CASCADE' });

// module.exports = {
//     Order,
//     Product
// }